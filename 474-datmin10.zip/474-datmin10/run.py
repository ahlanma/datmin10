from app import app, render_template, request
app.run(debug=True)
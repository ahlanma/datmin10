from app import app, render_template
app.run(debug=True)
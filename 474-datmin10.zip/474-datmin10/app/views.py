from app import app, render_template, request

@app.route('/')
def home():
    return render_template('index.html')

@app.route("/")
def index():
  return render_template('utama.html')

@app.route('/hitung', methods = ['POST'])
def hitung():
  bil1 = int(request.form['bil1'])
  bil2 = int(request.form['bil2'])

  hasil = bil1+bil2
  return render_template('utama.html', hasil = hasil, bil1 = bil1, bil2 = bil2)

if __name__ == '__main__':
  app.run(debug = True)